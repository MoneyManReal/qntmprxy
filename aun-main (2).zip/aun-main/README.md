## Details
The Official Proxy for Art Universal
https://discord.gg/jebDGUchyU (Discord)
## Forking
Star if you fork!

## Contributors

@Desktop_bypassers (Discord) @wvrmattreborn (Discord)

